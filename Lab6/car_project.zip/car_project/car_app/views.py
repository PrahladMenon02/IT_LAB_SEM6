from django.shortcuts import render
from .models import Car  # Import the Car model

def index(request):
    manufacturers = Car.objects.all()  # Retrieve manufacturers using the Car model
    return render(request, 'car_app/index.html', {'manufacturers': manufacturers})


def result(request):
    if request.method == 'POST':
        manufacturer = request.POST['manufacturer']
        model_name = request.POST['model_name']
        return render(request, 'car_app/result.html', {'manufacturer': manufacturer, 'model_name': model_name})
    return render(request, 'car_app/index.html', {})

