from django.shortcuts import render

def calculate_total_amount(brand, items, quantity):
    # Implement your logic to calculate the total amount based on the selected brand, items, and quantity
    # For example:
    base_price = 100  # Replace with your actual base price
    item_price = 50    # Replace with your actual item price
    total_amount = base_price + item_price * int(quantity)
    return total_amount

def produce_bill(request):
    if request.method == 'POST':
        selected_brand = request.POST.get('brand')
        selected_items = request.POST.getlist('items')
        quantity = request.POST.get('quantity')
        # Calculate total amount using the defined function
        total_amount = calculate_total_amount(selected_brand, selected_items, quantity)
        return render(request, 'billing/bill.html', {'selected_brand': selected_brand, 'selected_items': selected_items, 'quantity': quantity, 'total_amount': total_amount})
    else:
        # Handle GET request if needed
        return render(request, 'billing/produce_bill.html')
