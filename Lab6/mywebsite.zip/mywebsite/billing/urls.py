from django.urls import path
from .views import produce_bill

urlpatterns = [
    path('produce-bill/', produce_bill, name='produce_bill'),
]
