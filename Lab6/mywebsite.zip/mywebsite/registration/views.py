from django.shortcuts import render

def register(request):
    return render(request, 'registration/register.html')

def success(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        email = request.POST.get('email')
        contact_number = request.POST.get('contact_number')
        return render(request, 'registration/success.html',
                      {'username': username, 'email': email, 'contact_number': contact_number})
    else:
        # Handle GET request if needed
        return render(request, 'registration/register.html')
